local inifile = require "inifile"

os.chdir(App:GetScriptDir())

local config = inifile.parse("iniconfig.ini")

Alert(config['square']['name'])